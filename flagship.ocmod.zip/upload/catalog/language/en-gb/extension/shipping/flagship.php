<?php
// Text
$_['text_title']       = 'FlagShip';
$_['text_description'] = 'FlagShip Shipping';
