<?php

require_once(DIR_STORAGE . 'vendor/autoload.php');

use Flagship\Shipping\Flagship;
use Flagship\Shipping\Exceptions\ValidateTokenException;

class ModelExtensionShippingflagship extends Model{

    public function createFlagshipShipmentsTable() : bool {
        $query = "CREATE TABLE IF NOT EXISTS `".DB_PREFIX."flagship_shipments` (
                    `id` INT(2) UNSIGNED NOT NULL AUTO_INCREMENT,
                    `order_id` INT(2) UNSIGNED NOT NULL DEFAULT '0',
                    `flagship_shipment_id` INT(2) UNSIGNED DEFAULT NULL,
                    `shipment_status` VARCHAR(10) DEFAULT NULL,
                    PRIMARY KEY (`id`)
                )";
        $this->db->query($query);
        return true;
    }

    public function dropTables() : bool {
        $dropFlagshipBoxes = "DROP TABLE `".DB_PREFIX."flagship_boxes`";
        $dropFlagshipShipments = "DROP TABLE `".DB_PREFIX."flagship_shipments`";
        $this->db->query($dropFlagshipBoxes);
        $this->db->query($dropFlagshipShipments);
        return true;
    }

    public function updateFlagshipShipmentId(int $flagship_shipment_id,int $order_id, string $shipment_status) : int {
        $query = "INSERT INTO `".DB_PREFIX."flagship_shipments` SET `order_id`=".$order_id.", `flagship_shipment_id`=".$flagship_shipment_id.", `shipment_status`='".$shipment_status."'";
        $this->db->query($query);
        return 0;
    }

    public function getFlagshipShipmentId(int $order_id) : int {
        $query = $this->db->query("SELECT `flagship_shipment_id` FROM ".DB_PREFIX."flagship_shipments WHERE order_id = ".$order_id);
        return count($query->row) > 0 ? $query->row['flagship_shipment_id'] : 0;
    }

    public function getShipmentStatus(int $order_id) : ?string {
        $query = $this->db->query("SELECT `shipment_status` FROM `".DB_PREFIX."flagship_shipments` where `order_id`=".$order_id);
        return count($query->row) > 0 ? $query->row["shipment_status"] : NULL;
    }

    public function updateShipmentStatus(int $shipment_id) : int {
        if($shipment_id != 0){
            $flagship = new Flagship($this->config->get('shipping_flagship_token'), $this->config->get('smartship_api_url'), 'OpenCart', '1.0.0');
            $shipmentStatus = $flagship->getShipmentByIdRequest($shipment_id)->execute()->getStatus();
            $query = "UPDATE `".DB_PREFIX."flagship_shipments` set `shipment_status`='".$shipmentStatus."' where `flagship_shipment_id`=".$shipment_id;
            $this->db->query($query);
        }
        return 0;
    }

    public function addUrls() : bool {
        $this->db->query("INSERT INTO ".DB_PREFIX."setting SET `store_id` = '0', `code` = 'shipping_flagship', `key` = 'smartship_api_url', `value` = 'https://api.smartship.io' ");
        $this->db->query("INSERT INTO ".DB_PREFIX."setting SET `store_id` = '0', `code` = 'shipping_flagship', `key` = 'smartship_web_url', `value` = 'https://smartship-ng.flagshipcompany.com' ");
        return true;
    }

    public function getImperialLengthClass() : int {
        $query = $this->db->query("SELECT `length_class_id` FROM ".DB_PREFIX."length_class_description where unit = 'in'");
        return $query->row['length_class_id'];
    }

    public function getImperialWeightClass() : int {
        $query = $this->db->query("SELECT `weight_class_id` FROM ".DB_PREFIX."weight_class_description where unit = 'lb'");
        return $query->row['weight_class_id'];
    }

    public function isFlagshipInstalled() : int {
        $query = $this->db->query("SELECT `code` FROM ".DB_PREFIX."extension WHERE `code` = 'flagship'");
        return count($query->rows);
    }

    public function createFlagshipBoxesTable() : bool {
        $query = $this->db->query("
                CREATE TABLE IF NOT EXISTS `".DB_PREFIX."flagship_boxes` (
                    `id` INT(2) UNSIGNED NOT NULL AUTO_INCREMENT,
                    `box_model` VARCHAR(25) NULL DEFAULT 'NULL',
                    `length` INT(2) UNSIGNED NOT NULL DEFAULT '1',
                    `width` INT(2) UNSIGNED NOT NULL DEFAULT '1',
                    `height` INT(2) UNSIGNED NOT NULL DEFAULT '1',
                    `weight` INT(2) UNSIGNED NOT NULL DEFAULT '1',
                    `max_weight` INT(2) UNSIGNED NOT NULL DEFAULT '1',
                    PRIMARY KEY (`id`)
                )
            ");
        return true;
    }

    public function addBox(array $box) : bool {
        $query = $this->db->query("
                INSERT INTO `".DB_PREFIX."flagship_boxes` SET box_model = '".$box['box_model']."', length = ".$box['length'].", width = ".$box['width'].", height = ".$box['height'].", weight = ".$box['weight'].", max_weight = ".$box['max_weight']);
        return true;
    }

    public function getAllBoxes() : array {
        $query = $this->db->query("SELECT * from ".DB_PREFIX."flagship_boxes");
        return $query->rows;
    }

    public function deleteBox(int $id) : int {
        $query = $this->db->query("Delete from ".DB_PREFIX."flagship_boxes WHERE `id` = ".$id);
        return 0;
    }
}
